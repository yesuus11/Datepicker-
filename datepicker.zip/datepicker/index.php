<!DOCTYPE html>
<html>
<head>
	<title>jQuery Datepicker</title>
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	<script src="js/jquery-1.12.4.js"></script>
	<script src="js/jquery-ui.js"></script>
</head>
<body>
Choose Date: <input type="text" name="select_date" id="select_date">
<script type="text/javascript">
	$(document).ready(function(){
		$("#select_date").datepicker();
	});
</script>
</body>
</html>